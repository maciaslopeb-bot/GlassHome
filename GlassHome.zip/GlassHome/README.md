# Glass Home – an ad-free, glassy launcher for Fire TV

## What it does
- Frosted-glass dock with all your apps (TV banners when the app has one)
- No promoted rows, no ads, no recommendations
- Clock and date
- Change wallpaper: 6 built-in styles, or any image from Downloads / Pictures / a file browser
- Long-press an app (hold OK): pin to front, hide, or app info
- Menu button (the three lines) opens settings

## Build the APK (once, on a computer)
1. Install Android Studio and open this `GlassHome` folder.
2. Wait for Gradle sync (it downloads what it needs).
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is `app/build/outputs/apk/debug/app-debug.apk`.

## Install on Fire TV with Downloader
1. Upload `app-debug.apk` somewhere with a direct link (Google Drive, Dropbox, GitHub release).
2. Open Downloader on the Fire TV, enter the link, install.
3. Or from the computer: `adb connect <fire-tv-ip>` then `adb install app-debug.apk`.

## Making it your Home screen
Fire OS may still send the Home button to Amazon's launcher. You can always open
Glass Home from Your Apps & Channels. Home-button replacement needs a workaround
(some people use a launcher-manager app or ADB); I haven't tested this on your device.

## Using your own wallpaper
Save an image to Downloads with Downloader, then Wallpaper > Image from Downloads / Pictures.
