package com.glasshome.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.widget.FrameLayout

/**
 * A frosted-glass panel. It draws the matching slice of a pre-blurred copy of the
 * wallpaper behind its content, then a soft white sheen and a thin bright edge.
 * Works on every Android version (no RenderEffect needed), including older Fire TVs.
 */
class GlassPanel(ctx: Context, private val radiusDp: Float = 28f) : FrameLayout(ctx) {

    /** Blurred full-screen wallpaper. Must be the same aspect as the screen. */
    var backdrop: Bitmap? = null
        set(value) {
            field = value
            invalidate()
        }

    private val d = ctx.resources.displayMetrics.density
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val rect = RectF()
    private val dst = Rect()
    private val loc = IntArray(2)
    private var ring = false

    init {
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = radiusDp * d
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        sheen.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(78, 255, 255, 255), Color.argb(26, 255, 255, 255),
            Shader.TileMode.CLAMP
        )
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        ring = gainFocus
        val s = if (gainFocus) 1.08f else 1f
        animate().scaleX(s).scaleY(s).setDuration(140).start()
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        c.save()
        c.clipPath(path)
        val b = backdrop
        if (b != null) {
            getLocationInWindow(loc)
            c.save()
            c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            dst.set(0, 0, rootView.width, rootView.height)
            c.drawBitmap(b, null, dst, bmpPaint)
            c.restore()
        }
        c.drawRect(rect, sheen)
        c.restore()

        edge.color = if (ring) Color.WHITE else Color.argb(110, 255, 255, 255)
        edge.strokeWidth = (if (ring) 3f else 1.5f) * d
        c.drawPath(path, edge)
    }
}
