package com.glasshome.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

class MainActivity : Activity() {

    private class AppEntry(val pkg: String, val label: String, val info: ResolveInfo)

    private val prefs by lazy { getSharedPreferences("glass", MODE_PRIVATE) }
    private lateinit var bg: ImageView
    private lateinit var dockRow: LinearLayout
    private lateinit var dockScroll: HorizontalScrollView
    private val panels = mutableListOf<GlassPanel>()

    private val presets: List<Pair<String, IntArray>> = listOf(
        "Aurora" to cols("#0B1026", "#3B82F6", "#8B5CF6", "#10B981"),
        "Sunset" to cols("#1A0B2E", "#F97316", "#EC4899", "#6366F1"),
        "Ocean" to cols("#031B2E", "#06B6D4", "#2563EB", "#14B8A6"),
        "Midnight" to cols("#05060F", "#312E81", "#1E3A8A", "#6D28D9"),
        "Forest" to cols("#07140E", "#16A34A", "#065F46", "#CA8A04"),
        "Rose" to cols("#1F0A14", "#F43F5E", "#FB7185", "#A855F7")
    )

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadWallpaper()
    }

    override fun onResume() {
        super.onResume()
        refreshDock()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home pressed while already home: jump back to the first app.
        dockScroll.smoothScrollTo(0, 0)
        dockRow.getChildAt(0)?.requestFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher has nowhere to go "back" to.
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showSettingsMenu()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val root = FrameLayout(this)

        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        val scrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x40000000, 0x00000000, 0x99000000.toInt())
            )
        }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        // Top bar: clock/date on the left, glass pills on the right
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val clockCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "H:mm"
            setTextColor(Color.WHITE)
            textSize = 64f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setShadowLayer(14f, 0f, 2f, 0x66000000)
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, MMMM d"
            format24Hour = "EEEE, MMMM d"
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 20f
            setShadowLayer(10f, 0f, 2f, 0x66000000)
        }
        clockCol.addView(clock)
        clockCol.addView(date)
        top.addView(clockCol, LinearLayout.LayoutParams(0, -2, 1f))

        val wallpaperPill = pill("Wallpaper") { showWallpaperMenu() }
        val settingsPill = pill("Settings") { showSettingsMenu() }
        top.addView(wallpaperPill, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(14) })
        top.addView(settingsPill, LinearLayout.LayoutParams(-2, -2))

        root.addView(top, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.TOP
            setMargins(dp(56), dp(36), dp(56), 0)
        })

        // Bottom: glass dock holding all apps
        val dock = GlassPanel(this, 34f)
        panels += dock
        dockScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(dp(18), dp(22), dp(18), dp(22))
        }
        dockRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dockScroll.addView(dockRow)
        dock.addView(dockScroll)
        root.addView(dock, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM
            setMargins(dp(40), 0, dp(40), dp(40))
        })

        setContentView(root)
    }

    private fun pill(label: String, onClick: () -> Unit): GlassPanel {
        val p = GlassPanel(this, 24f)
        p.isFocusable = true
        p.isClickable = true
        p.setOnClickListener { onClick() }
        val tv = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(26), dp(12), dp(26), dp(12))
        }
        p.addView(tv)
        panels += p
        return p
    }

    private fun makeTile(e: AppEntry): View {
        val tile = FrameLayout(this)
        tile.isFocusable = true
        tile.isClickable = true
        tile.tag = e.pkg

        val card = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0x33000000)
            }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }

        val banner = try {
            e.info.activityInfo.loadBanner(packageManager)
        } catch (_: Exception) {
            null
        }

        if (banner != null) {
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageDrawable(banner)
            }
            card.addView(iv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            val icon = ImageView(this).apply { setImageDrawable(e.info.loadIcon(packageManager)) }
            col.addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))
            col.addView(TextView(this).apply {
                text = e.label
                setTextColor(Color.WHITE)
                textSize = 14f
                maxLines = 1
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(6), dp(8), 0)
            })
            card.addView(col, FrameLayout.LayoutParams(-1, -1))
        }
        tile.addView(card, FrameLayout.LayoutParams(-1, -1))

        val ring = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.TRANSPARENT)
                setStroke(dp(3), Color.WHITE)
            }
            visibility = View.GONE
        }
        tile.addView(ring, FrameLayout.LayoutParams(-1, -1))

        tile.setOnFocusChangeListener { _, focused ->
            ring.visibility = if (focused) View.VISIBLE else View.GONE
            val s = if (focused) 1.1f else 1f
            tile.animate().scaleX(s).scaleY(s).setDuration(140).start()
        }
        tile.setOnClickListener { launch(e.pkg) }
        tile.setOnLongClickListener {
            showTileMenu(e)
            true
        }
        return tile
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val map = LinkedHashMap<String, AppEntry>()
        // TV apps first, so their banners are used when an app has both entries
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || map.containsKey(p)) continue
                map[p] = AppEntry(p, ri.loadLabel(pm).toString(), ri)
            }
        }
        return map.values.toList()
    }

    private fun refreshDock() {
        val hidden = getSet("hidden")
        val pinned = getSet("pinned")
        val apps = loadApps()
            .filter { it.pkg !in hidden }
            .sortedWith(compareBy({ it.pkg !in pinned }, { it.label.lowercase() }))

        val keepFocus = currentFocus?.tag as? String
        dockRow.removeAllViews()
        for (e in apps) {
            dockRow.addView(makeTile(e), LinearLayout.LayoutParams(dp(214), dp(120)).apply {
                setMargins(dp(14), 0, dp(14), 0)
            })
        }
        dockRow.post {
            var target: View? = dockRow.getChildAt(0)
            for (i in 0 until dockRow.childCount) {
                if (dockRow.getChildAt(i).tag == keepFocus) target = dockRow.getChildAt(i)
            }
            target?.requestFocus()
        }
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            toast("Can't open that app")
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
        } catch (_: Exception) {
            toast("Can't open that app")
        }
    }

    // ---------------------------------------------------------------- menus

    private fun showTileMenu(e: AppEntry) {
        val isPinned = e.pkg in getSet("pinned")
        val items = arrayOf(
            if (isPinned) "Unpin from front" else "Pin to front",
            "Hide from home",
            "App info"
        )
        AlertDialog.Builder(this)
            .setTitle(e.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> { toggle("pinned", e.pkg); refreshDock() }
                    1 -> { toggle("hidden", e.pkg); refreshDock() }
                    else -> try {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}"))
                        )
                    } catch (_: Exception) {
                        toast("App info isn't available on this device")
                    }
                }
            }
            .show()
    }

    private fun showWallpaperMenu() {
        val items = presets.map { it.first } +
            listOf("Image from Downloads / Pictures…", "Browse files…")
        AlertDialog.Builder(this)
            .setTitle("Wallpaper")
            .setItems(items.toTypedArray()) { _, which ->
                when {
                    which < presets.size -> {
                        prefs.edit().putString("wp", "preset:$which").apply()
                        loadWallpaper()
                    }
                    which == presets.size -> showDeviceImages()
                    else -> browseFiles()
                }
            }
            .show()
    }

    private fun showSettingsMenu() {
        val items = arrayOf("Restore hidden apps", "Fire TV settings")
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showUnhide()
                    else -> try {
                        startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        toast("Couldn't open settings")
                    }
                }
            }
            .show()
    }

    private fun showUnhide() {
        val hidden = getSet("hidden").toList()
        if (hidden.isEmpty()) {
            toast("No hidden apps")
            return
        }
        val labels = hidden.map { pkg ->
            try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) {
                pkg
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Tap an app to show it again")
            .setItems(labels.toTypedArray()) { _, which ->
                toggle("hidden", hidden[which])
                refreshDock()
            }
            .show()
    }

    // ---------------------------------------------------------------- wallpaper

    private fun showDeviceImages() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), REQ_PERM)
            return
        }
        val exts = setOf("jpg", "jpeg", "png", "webp")
        val dirs = listOf(
            Environment.DIRECTORY_DOWNLOADS,
            Environment.DIRECTORY_PICTURES,
            Environment.DIRECTORY_DCIM
        ).map { Environment.getExternalStoragePublicDirectory(it) }
        val files = dirs.flatMap { dir ->
            if (!dir.exists()) emptyList()
            else dir.walkTopDown().maxDepth(2)
                .filter { it.isFile && it.extension.lowercase() in exts }
                .toList()
        }.sortedByDescending { it.lastModified() }.take(40)

        if (files.isEmpty()) {
            toast("No images found in Downloads or Pictures. Save one there first (Downloader works).")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Choose an image")
            .setItems(files.map { it.name }.toTypedArray()) { _, which ->
                setCustom { FileInputStream(files[which]) }
            }
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) showDeviceImages()
            else toast("Storage permission is needed to list your images")
        }
    }

    private fun browseFiles() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_PICK)
        } catch (_: Exception) {
            toast("No file browser on this device. Use \"Image from Downloads / Pictures\" instead.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            setCustom { contentResolver.openInputStream(uri) }
        }
    }

    private fun setCustom(open: () -> InputStream?) {
        val bmp = decodeSampled(open)
        if (bmp == null) {
            toast("Couldn't read that image")
            return
        }
        val (w, h) = targetSize()
        val fit = fitToScreen(bmp, w, h)
        FileOutputStream(File(filesDir, "wallpaper.jpg")).use {
            fit.compress(Bitmap.CompressFormat.JPEG, 92, it)
        }
        prefs.edit().putString("wp", "custom").apply()
        loadWallpaper()
    }

    private fun loadWallpaper() {
        val (w, h) = targetSize()
        val choice = prefs.getString("wp", "preset:0") ?: "preset:0"
        var raw: Bitmap? = null
        if (choice == "custom") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) raw = BitmapFactory.decodeFile(f.path)
        }
        if (raw == null) {
            val idx = (choice.removePrefix("preset:").toIntOrNull() ?: 0).coerceIn(0, presets.size - 1)
            raw = presetBitmap(idx, w, h)
        }
        val fit = fitToScreen(raw, w, h)
        bg.setImageBitmap(fit)
        val blurred = blur(fit)
        panels.forEach { it.backdrop = blurred }
    }

    private fun targetSize(): Pair<Int, Int> {
        val dm = resources.displayMetrics
        var w = dm.widthPixels
        var h = dm.heightPixels
        if (w > 1920) {
            h = h * 1920 / w
            w = 1920
        }
        return Pair(w, h)
    }

    private fun presetBitmap(i: Int, w: Int, h: Int): Bitmap {
        val p = presets[i].second
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(p[0])
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val spots = arrayOf(
            floatArrayOf(0.18f, 0.25f, 0.70f),
            floatArrayOf(0.85f, 0.15f, 0.60f),
            floatArrayOf(0.60f, 0.95f, 0.80f)
        )
        for (k in 0..2) {
            val s = spots[k]
            val col = p[k + 1]
            val inner = Color.argb(200, Color.red(col), Color.green(col), Color.blue(col))
            val outer = Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))
            paint.shader = RadialGradient(s[0] * w, s[1] * h, s[2] * w, inner, outer, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        }
        return bmp
    }

    private fun fitToScreen(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
        val m = Matrix()
        m.postScale(scale, scale)
        m.postTranslate((w - src.width * scale) / 2f, (h - src.height * scale) / 2f)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun decodeSampled(open: () -> InputStream?): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1920 && bounds.outHeight / (sample * 2) >= 1080) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return open()?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    // ---------------------------------------------------------------- blur

    private fun blur(src: Bitmap): Bitmap {
        val small = Bitmap.createScaledBitmap(src, maxOf(1, src.width / 12), maxOf(1, src.height / 12), true)
        return boxBlur(small, 3, 2)
    }

    private fun boxBlur(bmp: Bitmap, radius: Int, passes: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val a = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        repeat(passes) {
            blurPass(a, b, w, h, radius, true)
            blurPass(b, a, w, h, radius, false)
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        val n = 2 * r + 1
        for (l in 0 until lines) {
            for (i in 0 until len) {
                var rr = 0
                var gg = 0
                var bb = 0
                for (k in -r..r) {
                    val j = (i + k).coerceIn(0, len - 1)
                    val p = if (horizontal) src[l * w + j] else src[j * w + l]
                    rr += (p shr 16) and 0xFF
                    gg += (p shr 8) and 0xFF
                    bb += p and 0xFF
                }
                val out = (0xFF shl 24) or ((rr / n) shl 16) or ((gg / n) shl 8) or (bb / n)
                if (horizontal) dst[l * w + i] = out else dst[i * w + l] = out
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun getSet(key: String): MutableSet<String> =
        HashSet(prefs.getStringSet(key, emptySet()) ?: emptySet())

    private fun toggle(key: String, value: String) {
        val s = getSet(key)
        if (!s.add(value)) s.remove(value)
        prefs.edit().putStringSet(key, s).apply()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_PICK = 11
        private const val REQ_PERM = 12

        private fun cols(vararg hex: String): IntArray = IntArray(hex.size) { Color.parseColor(hex[it]) }
    }
}
